pip install sympy numpy scipy
